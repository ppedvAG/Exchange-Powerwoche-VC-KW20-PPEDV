﻿Set-ExecutionPolicy RemoteSigned

$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection

Import-PSSession $Session -DisableNameChecking

###Trennen
Remove-PSSession $Session

Get-Mailbox
Get-Mailbox | Get-MailboxStatistics | sort totalitemsize -Descending | ft displayname,totalitemsize

Get-Mailbox -ResultSize unlimited | Get-MailboxStatistics | Sort-Object TotalItemSize -Descending | Select-Object DisplayName,ItemCount,TotalItemSize -first 10

Get-MailboxStatistics -Server $env:COMPUTERNAME | %{$_.TotalItemSize.Value.ToMB()} | Measure-Object -sum -average -max -min