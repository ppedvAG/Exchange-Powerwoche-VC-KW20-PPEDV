﻿Set-ExecutionPolicy RemoteSigned

$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection

Import-PSSession $Session -DisableNameChecking

###Trennen
Remove-PSSession $Session


update-help

Get-help Add-MailboxFolderPermission -Detailed

Get-Mailbox | Get-MailboxStatistics | sort totalitemsize -Descending | ft displayname,itemcount,totalitemsize

Get-MailboxStatistics -Identity admin | ft displayname,totalitemsize

Get-Mailbox -Identity admin | fl audit*

Get-MessageTrackingLog -ResultSize Unlimited -Start "Feb 20 2017” | select-object eventid,timestamp,source,messageid,sender,recipients,messagesubject | Out-Gridview

Get-MessageTrace -RecipientAddress andreas@democomp19.onmicrosoft.com | Out-GridView