﻿Connect-SPOService -Url https://m365x396008-admin.sharepoint.com
Invoke-SPOSiteSwap -SourceUrl https://m365x853937.sharepoint.com/sites/Alexander-Communication -TargetUrl https://M365x853937.onmicrosoft.com -ArchiveUrl https://M365x853937.onmicrosoft.com/sites/oldPortalXY
#-SourceURL = die Site die es werden soll
#-TargelURL = unter der URL solls später erreichbar sein
#-ArchivURL = alte Seite
# alle Seiten müssen bereits bestehen!...ausser Archivseite 